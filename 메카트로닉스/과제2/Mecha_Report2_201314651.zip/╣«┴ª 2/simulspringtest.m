figure(1)
plot(tout,xs.signals.values(:,1));