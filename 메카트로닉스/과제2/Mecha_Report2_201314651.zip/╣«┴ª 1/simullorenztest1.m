figure(1)
plot(tout,xs.signals.values);
figure(2)
plot3(xs.signals.values(:,1), xs.signals.values(:,2), xs.signals.values(:,3));