figure(1)
plot(tout,x1.signals.values);
hold on
plot(tout,x2.signals.values);
plot(tout,x3.signals.values);
figure(2)
plot3(x1.signals.values, x2.signals.values, x3.signals.values);
